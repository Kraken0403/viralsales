
import HomeTestimonial from '~/components/HomeTestimonial.vue';
<template>
    <div class="about">
        <!-- About Hero banner -->
        <Abhero />
        <!-- Goal of the company -->
        <Abintro />
        <!-- Map of the place -->
        <Abimage/>
        <!-- Images and Stats -->
        <Abstats />
        <HomeTestimonial/>
        <!-- Awards Won -->
        <Footer />
        <!-- Contact Details -->
    </div>
</template>