<template>

    <HomeHero />
    <HomeBanner />
    <HomeAbout/>
    <HomeProjects/>
    <HomeProducts />
    <HomeNews />
    <HomeTestimonial />
    <Footer />

</template>



<style src="../components/cursor.scss">
    
</style>

