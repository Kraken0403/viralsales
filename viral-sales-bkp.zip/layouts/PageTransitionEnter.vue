<template>
    <div class="page-transition">
      <slot />
    </div>
  </template>

  
  <style scoped>
  .page-transition {
    opacity: 0;
    transition: none; 
  }
  </style>
  