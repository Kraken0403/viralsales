<template>
    <div class="ab-intro section">
        <div class="container-narrow">
            <div class="ab-intro-title">
                <h1>
                    <div class="">
                        Viral
                    </div>

                    <div class="">
                        <i>Sales & Traders</i>
                    </div>
                </h1>
            </div>
            <!-- <div class="svg-line">
                <div class="svg-box"></div>
                <svg>
                    <path :d="curvePath"/>
                </svg>
            </div> -->
            <hr>
            <div class="ab-intro-content">
                <div class="row">
                    <div class="col-25">
                        <div class="caption">
                            <h2>Know Your fav <br/>paint dealers</h2>
                        </div>
                    </div>
                    <div class="col-75">
                        <div class="main-content">
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries
                            </p>
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
// const progress = 0;
// const width = window.innerWidth * 0.7;
// let x = 0.5;

// const setPath = (progress) => {
// }
// export default {
    
//     computed: {
//         curvePath() {
//         // Define the curve path here
//             return `M 0 50 Q ${width * x} 50 ${width} 50`;
//         },
//     },

//     onMounted: {
//         // function
//     //    setPath(progress)
//     }
// }
</script>

<style src="./Abintro.scss" scoped>
</style>