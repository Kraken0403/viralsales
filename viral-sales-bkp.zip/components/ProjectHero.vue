<template>
    <div class="project-hero section">
        <div class="container-narrow">
            <div class="project-hero-title">
                <h1>Transformative<strong> Projects</strong>  <br/>with our <i>Top-Quality Paints</i></h1>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style src="./ProjectHero.scss" scoped>

</style>