<template>
    <div class="project-card-wrapper section">
        <div class="container-narrow">
            <div class="project-card">
                <div class="project-card-image">
                    <img src="../assets/images/sample-5.png" alt="">
                </div>
                <div class="project-card-content">
                    <h2>Project Title</h2>
                    <p>There are two main ways to add an image in Nuxt, depending on whether you want Nuxt to optimize the image or not, and where you store the image file.</p>
                    <div class="project-tags">
                        <div class="project-tag">
                            <p>Tag 1</p>
                        </div>
                        <div class="project-tag">
                            <p>Tag 2</p>
                        </div>
                        <div class="project-tag">
                            <p>Tag 3</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="project-card">
                <div class="project-card-image">
                    <img src="../assets/images/sample-5.png" alt="">
                </div>
                <div class="project-card-content">
                    <h2>Project Title</h2>
                    <p>There are two main ways to add an image in Nuxt, depending on whether you want Nuxt to optimize the image or not, and where you store the image file.</p>
                    <div class="project-tags">
                        <div class="project-tag">
                            <p>Tag 1</p>
                        </div>
                        <div class="project-tag">
                            <p>Tag 2</p>
                        </div>
                        <div class="project-tag">
                            <p>Tag 3</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="project-card">
                <div class="project-card-image">
                    <img src="../assets/images/sample-5.png" alt="">
                </div>
                <div class="project-card-content">
                    <h2>Project Title</h2>
                    <p>There are two main ways to add an image in Nuxt, depending on whether you want Nuxt to optimize the image or not, and where you store the image file.</p>
                    <div class="project-tags">
                        <div class="project-tag">
                            <p>Tag 1</p>
                        </div>
                        <div class="project-tag">
                            <p>Tag 2</p>
                        </div>
                        <div class="project-tag">
                            <p>Tag 3</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style src="./ProjectCard.scss" scoped>

</style>