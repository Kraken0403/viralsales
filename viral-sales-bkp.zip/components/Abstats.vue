<template>
    <div class="ab-stats section">
        <div class="container-narrow">
            <div class="ab-stats-title">
                <h1>
                    <div class="">
                        How we
                    </div>

                    <div class="">
                        <i>Stand out</i>
                    </div>
                </h1>
            </div>
            <hr>
            <div class="ab-stats-content">
                <div class="row">
                    <div class="col-25">
                        <div class="caption">
                            <h2>Our Mission</h2>
                        </div>
                    </div>
                    <div class="col-75">
                        <div class="main-content">
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries
                            </p>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-25">
                        <div class="caption">
                            <h2>Our Values</h2>
                        </div>
                    </div>
                    <div class="col-75">
                        <div class="main-content">
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries
                            </p>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-25">
                        <div class="caption">
                            <h2>Our Promise</h2>
                        </div>
                    </div>
                    <div class="col-75">
                        <div class="main-content">
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries
                            </p>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-25">
                        <div class="caption">
                            <h2>Our Clients</h2>
                        </div>
                    </div>
                    <div class="col-75">
                        <div class="main-content">
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries
                            </p>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</template>

<script>
</script>

<style src="./Abstats.scss" scoped>

</style>