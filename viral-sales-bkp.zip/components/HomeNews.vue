<template>
    <div class="home-news">
        <div class="container-narrow">
            <div class="news-container">
                <div class="row">
                    <div class="col-50">
                        <div class="news-content">
                            <div class="news-tag">
                                <h4>News/Client</h4>
                            </div>
                            <div class="news-text">
                                <h4>Title of news</h4>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea  commodo consequat.  
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-50">
                        <div class="news-image">
                            <img src="../assets/images/news.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

</script>

<style src="./HomeNews.scss" scoped>

</style>