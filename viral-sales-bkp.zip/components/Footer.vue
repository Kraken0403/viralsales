<template>
    <div class="footer">
        <div class="container-narrow">
            <div class="footer-wrapper">
                <div class="row">
                    <div class="col-50">
                        <div class="footer-cta">
                            <h2>Can't Descide which color suits your <br> place the best?</h2>
                            <Button buttonText="Contact Us" />
                        </div>
                    </div>
                    <div class="col-50">
                        <div class="footer-links">
                            <h6>
                                Quick Links
                            </h6>
                            <ul class="footer-menu">
                                <li class="footer-item">
                                    About Us
                                </li>
                                <li class="footer-item">
                                    Products
                                </li>
                                <li class="footer-item">
                                    Our Work
                                </li>
                                <li class="footer-item">
                                    Privacy policy
                                </li>
                                <li class="footer-item">
                                    Terms and Conditions
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-copyright">
                    <div class="row">
                        <div class="col-25">
                            <div class="social">
                                <p>Follow us:</p>
                            </div>
                        </div>
                        <div class="col-25">
                            <p>Visit Us</p>
                        </div>
                        <div class="col-25">
                            <p>review Us</p>
                        </div>
                        <div class="col-25">
                            <p>Contact Us</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
    import Button from './Button.vue';
</script>

<style src="./Footer.scss" scoped>

</style>